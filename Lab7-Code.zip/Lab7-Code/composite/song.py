# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:16:42 2026

@author: AFraN NaSiR
"""

from .media_component import MediaComponent

class Song(MediaComponent):
    """Leaf node in the composite pattern - represents a single song"""
    
    def __init__(self, title: str, artist: str, duration: int, genre: str, is_explicit: bool = False):
        self._title = title
        self._artist = artist
        self._duration = duration
        self._genre = genre
        self._is_explicit = is_explicit
    
    def get_name(self) -> str:
        return f"{self._title} by {self._artist}"
    
    def get_duration(self) -> int:
        return self._duration
    
    def play(self) -> None:
        print(f"🎵 Playing song: {self._title} [{self._duration}s]")
    
    def accept(self, visitor):
        visitor.visit_song(self)
    
    # Getters for Visitor pattern
    @property
    def title(self) -> str:
        return self._title
    
    @property
    def artist(self) -> str:
        return self._artist
    
    @property
    def genre(self) -> str:
        return self._genre
    
    @property
    def is_explicit(self) -> bool:
        return self._is_explicit