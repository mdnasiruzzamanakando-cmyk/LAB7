# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:22:07 2026

@author: AFraN NaSiR
"""

from typing import List
from composite.media_component import MediaComponent
from .playback_strategy import PlaybackStrategy
from .sequential_play import SequentialPlay

class PlayerContext:
    """Context class that uses a strategy for playback"""
    
    def __init__(self, media_list: List[MediaComponent]):
        self._media_list = media_list
        self._current_strategy: PlaybackStrategy = SequentialPlay()  # default strategy
    
    def set_playback_strategy(self, strategy: PlaybackStrategy) -> None:
        """Change the playback strategy at runtime"""
        self._current_strategy = strategy
        print(f"\n✓ Switched to {strategy.get_strategy_name()} playback mode")
    
    def play(self) -> None:
        """Execute the current playback strategy"""
        if self._current_strategy is None:
            print("No playback strategy set!")
            return
        self._current_strategy.play(self._media_list)
    
    @property
    def current_strategy(self) -> PlaybackStrategy:
        return self._current_strategy