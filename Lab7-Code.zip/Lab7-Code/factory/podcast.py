# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:23:49 2026

@author: AFraN NaSiR
"""

from composite.media_component import MediaComponent

class Podcast(MediaComponent):
    """Podcast media type created by Factory pattern"""
    
    def __init__(self, title: str, host: str, duration: int, episode: str):
        self._title = title
        self._host = host
        self._duration = duration
        self._episode = episode
    
    def get_name(self) -> str:
        return f"{self._title} (Ep.{self._episode} with {self._host})"
    
    def get_duration(self) -> int:
        return self._duration
    
    def play(self) -> None:
        print(f"🎙️ Playing podcast: {self._title} - Episode {self._episode} [{self._duration}s]")
    
    def accept(self, visitor):
        visitor.visit_podcast(self)
    
    @property
    def title(self) -> str:
        return self._title
    
    @property
    def host(self) -> str:
        return self._host
    
    @property
    def episode(self) -> str:
        return self._episode