# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:24:46 2026

@author: AFraN NaSiR
"""

from .media_visitor import MediaVisitor

class DurationCalculator(MediaVisitor):
    """Concrete visitor that calculates total duration of all media"""
    
    def __init__(self):
        self._total_duration = 0
    
    def visit_song(self, song):
        self._total_duration += song.get_duration()
        print(f"  + Song: {song.title} ({song.get_duration()}s)")
    
    def visit_playlist(self, playlist):
        print(f"\n📁 Entering playlist: {playlist.get_name()}")
        # Don't add playlist duration here - children will be visited separately
    
    def visit_video(self, video):
        self._total_duration += video.get_duration()
        print(f"  + Video: {video.get_name()} ({video.get_duration()}s)")
    
    def visit_podcast(self, podcast):
        self._total_duration += podcast.get_duration()
        print(f"  + Podcast: {podcast.get_name()} ({podcast.get_duration()}s)")
    
    def get_total_duration(self) -> int:
        return self._total_duration
    
    def reset(self):
        self._total_duration = 0