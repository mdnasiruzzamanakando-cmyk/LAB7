# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:24:26 2026

@author: AFraN NaSiR
"""

from abc import ABC, abstractmethod

class MediaVisitor(ABC):
    """Visitor interface for operations on media components"""
    
    @abstractmethod
    def visit_song(self, song):
        pass
    
    @abstractmethod
    def visit_playlist(self, playlist):
        pass
    
    @abstractmethod
    def visit_video(self, video):
        pass
    
    @abstractmethod
    def visit_podcast(self, podcast):
        pass