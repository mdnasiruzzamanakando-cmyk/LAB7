# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:23:09 2026

@author: AFraN NaSiR
"""

from composite.song import Song
from .video import Video
from .podcast import Podcast

class MediaFactory:
    """Factory pattern for creating different types of media"""
    
    @staticmethod
    def create_audio(title: str, artist: str, duration: int, genre: str, is_explicit: bool = False) -> Song:
        """Create an audio track (Song)"""
        return Song(title, artist, duration, genre, is_explicit)
    
    @staticmethod
    def create_video(title: str, director: str, duration: int, resolution: str) -> Video:
        """Create a video"""
        return Video(title, director, duration, resolution)
    
    @staticmethod
    def create_podcast(title: str, host: str, duration: int, episode: str) -> Podcast:
        """Create a podcast episode"""
        return Podcast(title, host, duration, episode)
    
    @staticmethod
    def create_media(media_type: str, *params) -> object:
        """
        Factory method using type string
        Example: create_media("audio", "Title", "Artist", "180", "Pop")
        """
        media_type = media_type.lower()
        
        if media_type == "audio":
            return Song(params[0], params[1], int(params[2]), params[3], False)
        elif media_type == "video":
            return Video(params[0], params[1], int(params[2]), params[3])
        elif media_type == "podcast":
            return Podcast(params[0], params[1], int(params[2]), params[3])
        else:
            raise ValueError(f"Unknown media type: {media_type}")