#!/usr/bin/env python3
"""
SoundWave Music Streaming Service
Student: Akando Md Nasiruzzaman
ID: 23605108
Course: Software Development (Computer Science & Engineering)
Lab 7: Applied Design Patterns
"""

from abc import ABC, abstractmethod
from typing import List
import random

# ═══════════════════════════════════════════════════════════════════════════
# COMPOSITE PATTERN - Media Component Hierarchy
# ═══════════════════════════════════════════════════════════════════════════

class MediaComponent(ABC):
    """Abstract base class for all media components (Songs and Playlists)"""
    
    @abstractmethod
    def get_name(self) -> str:
        pass
    
    @abstractmethod
    def get_duration(self) -> int:
        pass
    
    @abstractmethod
    def play(self) -> None:
        pass
    
    @abstractmethod
    def accept(self, visitor):
        pass


class Song(MediaComponent):
    """Leaf node - represents a single song"""
    
    def __init__(self, title: str, artist: str, duration: int, genre: str, is_explicit: bool = False):
        self._title = title
        self._artist = artist
        self._duration = duration
        self._genre = genre
        self._is_explicit = is_explicit
    
    def get_name(self) -> str:
        return f"{self._title} by {self._artist}"
    
    def get_duration(self) -> int:
        return self._duration
    
    def play(self) -> None:
        print(f"🎵 Playing song: {self._title} [{self._duration}s]")
    
    def accept(self, visitor):
        visitor.visit_song(self)
    
    @property
    def title(self) -> str:
        return self._title
    
    @property
    def artist(self) -> str:
        return self._artist
    
    @property
    def genre(self) -> str:
        return self._genre
    
    @property
    def is_explicit(self) -> bool:
        return self._is_explicit


class Playlist(MediaComponent):
    """Composite node - can contain both Songs and other Playlists"""
    
    def __init__(self, name: str):
        self._name = name
        self._components: List[MediaComponent] = []
    
    def add_media(self, component: MediaComponent) -> None:
        self._components.append(component)
    
    def remove_media(self, component: MediaComponent) -> None:
        self._components.remove(component)
    
    def get_components(self) -> List[MediaComponent]:
        return self._components.copy()
    
    def get_name(self) -> str:
        return self._name
    
    def get_duration(self) -> int:
        total = 0
        for component in self._components:
            total += component.get_duration()
        return total
    
    def play(self) -> None:
        print(f"\n📁 === Playing Playlist: {self._name} ===")
        for component in self._components:
            component.play()
    
    def accept(self, visitor):
        visitor.visit_playlist(self)
        for component in self._components:
            component.accept(visitor)


# ═══════════════════════════════════════════════════════════════════════════
# STRATEGY PATTERN - Playback Algorithms
# ═══════════════════════════════════════════════════════════════════════════

class PlaybackStrategy(ABC):
    """Strategy interface for different playback algorithms"""
    
    @abstractmethod
    def play(self, playlist: List[MediaComponent]) -> None:
        pass
    
    @abstractmethod
    def get_strategy_name(self) -> str:
        pass


class SequentialPlay(PlaybackStrategy):
    """Concrete strategy - plays media in sequential order"""
    
    def play(self, playlist: List[MediaComponent]) -> None:
        print("\n[Sequential Mode] Playing in order:")
        for i, media in enumerate(playlist, 1):
            print(f"{i}. ", end="")
            media.play()
    
    def get_strategy_name(self) -> str:
        return "Sequential"


class ShufflePlay(PlaybackStrategy):
    """Concrete strategy - plays media in random order"""
    
    def __init__(self):
        self._random = random.Random()
    
    def play(self, playlist: List[MediaComponent]) -> None:
        print("\n[Shuffle Mode] Playing in random order:")
        shuffled = playlist.copy()
        self._random.shuffle(shuffled)
        
        for i, media in enumerate(shuffled, 1):
            print(f"{i}. ", end="")
            media.play()
    
    def get_strategy_name(self) -> str:
        return "Shuffle"


class PlayerContext:
    """Context class that uses a strategy for playback"""
    
    def __init__(self, media_list: List[MediaComponent]):
        self._media_list = media_list
        self._current_strategy: PlaybackStrategy = SequentialPlay()
    
    def set_playback_strategy(self, strategy: PlaybackStrategy) -> None:
        self._current_strategy = strategy
        print(f"\n✓ Switched to {strategy.get_strategy_name()} playback mode")
    
    def play(self) -> None:
        if self._current_strategy is None:
            print("No playback strategy set!")
            return
        self._current_strategy.play(self._media_list)
    
    @property
    def current_strategy(self) -> PlaybackStrategy:
        return self._current_strategy


# ═══════════════════════════════════════════════════════════════════════════
# FACTORY PATTERN - Media Creation
# ═══════════════════════════════════════════════════════════════════════════

class Video(MediaComponent):
    """Video media type"""
    
    def __init__(self, title: str, director: str, duration: int, resolution: str):
        self._title = title
        self._director = director
        self._duration = duration
        self._resolution = resolution
    
    def get_name(self) -> str:
        return f"{self._title} (directed by {self._director})"
    
    def get_duration(self) -> int:
        return self._duration
    
    def play(self) -> None:
        print(f"🎬 Playing video: {self._title} [{self._duration}s, {self._resolution}]")
    
    def accept(self, visitor):
        visitor.visit_video(self)
    
    @property
    def title(self) -> str:
        return self._title
    
    @property
    def director(self) -> str:
        return self._director
    
    @property
    def resolution(self) -> str:
        return self._resolution


class Podcast(MediaComponent):
    """Podcast media type"""
    
    def __init__(self, title: str, host: str, duration: int, episode: str):
        self._title = title
        self._host = host
        self._duration = duration
        self._episode = episode
    
    def get_name(self) -> str:
        return f"{self._title} (Ep.{self._episode} with {self._host})"
    
    def get_duration(self) -> int:
        return self._duration
    
    def play(self) -> None:
        print(f"🎙️ Playing podcast: {self._title} - Episode {self._episode} [{self._duration}s]")
    
    def accept(self, visitor):
        visitor.visit_podcast(self)
    
    @property
    def title(self) -> str:
        return self._title
    
    @property
    def host(self) -> str:
        return self._host
    
    @property
    def episode(self) -> str:
        return self._episode


class MediaFactory:
    """Factory pattern for creating different types of media"""
    
    @staticmethod
    def create_audio(title: str, artist: str, duration: int, genre: str, is_explicit: bool = False) -> Song:
        return Song(title, artist, duration, genre, is_explicit)
    
    @staticmethod
    def create_video(title: str, director: str, duration: int, resolution: str) -> Video:
        return Video(title, director, duration, resolution)
    
    @staticmethod
    def create_podcast(title: str, host: str, duration: int, episode: str) -> Podcast:
        return Podcast(title, host, duration, episode)
    
    @staticmethod
    def create_media(media_type: str, *params):
        media_type = media_type.lower()
        
        if media_type == "audio":
            return Song(params[0], params[1], int(params[2]), params[3], False)
        elif media_type == "video":
            return Video(params[0], params[1], int(params[2]), params[3])
        elif media_type == "podcast":
            return Podcast(params[0], params[1], int(params[2]), params[3])
        else:
            raise ValueError(f"Unknown media type: {media_type}")


# ═══════════════════════════════════════════════════════════════════════════
# VISITOR PATTERN - Reporting Operations
# ═══════════════════════════════════════════════════════════════════════════

class MediaVisitor(ABC):
    """Visitor interface for operations on media components"""
    
    @abstractmethod
    def visit_song(self, song):
        pass
    
    @abstractmethod
    def visit_playlist(self, playlist):
        pass
    
    @abstractmethod
    def visit_video(self, video):
        pass
    
    @abstractmethod
    def visit_podcast(self, podcast):
        pass


class DurationCalculator(MediaVisitor):
    """Concrete visitor that calculates total duration"""
    
    def __init__(self):
        self._total_duration = 0
    
    def visit_song(self, song):
        self._total_duration += song.get_duration()
        print(f"  + Song: {song.title} ({song.get_duration()}s)")
    
    def visit_playlist(self, playlist):
        print(f"\n📁 Entering playlist: {playlist.get_name()}")
    
    def visit_video(self, video):
        self._total_duration += video.get_duration()
        print(f"  + Video: {video.get_name()} ({video.get_duration()}s)")
    
    def visit_podcast(self, podcast):
        self._total_duration += podcast.get_duration()
        print(f"  + Podcast: {podcast.get_name()} ({podcast.get_duration()}s)")
    
    def get_total_duration(self) -> int:
        return self._total_duration
    
    def reset(self):
        self._total_duration = 0


class GenreCountVisitor(MediaVisitor):
    """Concrete visitor that counts media by genre"""
    
    def __init__(self):
        self._genre_counts: dict = {}
    
    def visit_song(self, song):
        genre = song.genre
        self._genre_counts[genre] = self._genre_counts.get(genre, 0) + 1
    
    def visit_playlist(self, playlist):
        pass
    
    def visit_video(self, video):
        self._genre_counts["Video"] = self._genre_counts.get("Video", 0) + 1
    
    def visit_podcast(self, podcast):
        self._genre_counts["Podcast"] = self._genre_counts.get("Podcast", 0) + 1
    
    def get_genre_counts(self) -> dict:
        return self._genre_counts


class ExplicitContentVisitor(MediaVisitor):
    """Concrete visitor that checks for explicit content"""
    
    def __init__(self):
        self._explicit_songs: List[str] = []
    
    def visit_song(self, song):
        if song.is_explicit:
            self._explicit_songs.append(song.title)
    
    def visit_playlist(self, playlist):
        pass
    
    def visit_video(self, video):
        pass
    
    def visit_podcast(self, podcast):
        pass
    
    def get_explicit_songs(self) -> List[str]:
        return self._explicit_songs
    
    def has_explicit_content(self) -> bool:
        return len(self._explicit_songs) > 0


# ═══════════════════════════════════════════════════════════════════════════
# MAIN PROGRAM
# ═══════════════════════════════════════════════════════════════════════════

def main():
    print("═" * 55)
    print("  SoundWave Music Streaming Service")
    print("  Student: Akando Md Nasiruzzaman")
    print("  ID: 23605108")
    print("═" * 55)
    print()
    
    # ========== TASK 2: COMPOSITE & STRATEGY ==========
    print("📌 TASK 2: Composite & Strategy Patterns")
    print("─" * 55)
    
    # Create media using Factory pattern
    song1 = MediaFactory.create_audio("Bohemian Rhapsody", "Queen", 355, "Rock")
    song2 = MediaFactory.create_audio("Imagine", "John Lennon", 183, "Pop")
    song3 = MediaFactory.create_audio("Billie Jean", "Michael Jackson", 294, "Pop")
    song4 = MediaFactory.create_audio("Lose Yourself", "Eminem", 326, "Hip Hop", True)
    video1 = MediaFactory.create_video("Inception Scene", "Christopher Nolan", 180, "1080p")
    podcast1 = MediaFactory.create_podcast("Tech Talk", "Jane Doe", 2700, "42")
    
    # Create nested playlist structure (Composite pattern)
    rock_playlist = Playlist("Rock Classics")
    rock_playlist.add_media(song1)
    
    pop_playlist = Playlist("Pop Hits")
    pop_playlist.add_media(song2)
    pop_playlist.add_media(song3)
    
    hiphop_playlist = Playlist("Hip Hop Mix")
    hiphop_playlist.add_media(song4)
    
    main_playlist = Playlist("My Favorites")
    main_playlist.add_media(rock_playlist)      # Nested playlist!
    main_playlist.add_media(pop_playlist)       # Nested playlist!
    main_playlist.add_media(hiphop_playlist)    # Nested playlist!
    main_playlist.add_media(video1)
    main_playlist.add_media(podcast1)
    
    # Create player context with the playlist
    player = PlayerContext([main_playlist])
    
    # Test sequential playback
    print("\n▶ Testing Sequential Playback:")
    player.set_playback_strategy(SequentialPlay())
    player.play()
    
    # Test shuffle playback
    print("\n▶ Testing Shuffle Playback:")
    player.set_playback_strategy(ShufflePlay())
    player.play()
    
    # ========== TASK 3: VISITOR & FACTORY ==========
    print("\n\n📌 TASK 3: Visitor & Factory Patterns")
    print("─" * 55)
    
    # Demonstrate Factory creating different media types
    print("\n🏭 Media Factory Demo:")
    media1 = MediaFactory.create_media("audio", "Shape of You", "Ed Sheeran", "233", "Pop")
    media2 = MediaFactory.create_media("video", "Python Tutorial", "Tech Guru", "600", "4K")
    media3 = MediaFactory.create_media("podcast", "Daily News", "News Anchor", "1800", "101")
    
    print(f"  Created: {media1.get_name()}")
    print(f"  Created: {media2.get_name()}")
    print(f"  Created: {media3.get_name()}")
    
    # Test Duration Calculator Visitor
    print("\n⏱️ Duration Calculator Visitor:")
    duration_calc = DurationCalculator()
    main_playlist.accept(duration_calc)
    
    total_seconds = duration_calc.get_total_duration()
    minutes = total_seconds // 60
    seconds = total_seconds % 60
    
    print("\n" + "═" * 55)
    print(f"📊 Total Duration: {total_seconds} seconds")
    print(f"   ({minutes} minutes, {seconds} seconds)")
    
    # Test Genre Count Visitor
    print("\n🎵 Genre Count Visitor:")
    genre_visitor = GenreCountVisitor()
    main_playlist.accept(genre_visitor)
    print(f"  Genre Distribution: {genre_visitor.get_genre_counts()}")
    
    # Test Explicit Content Visitor
    print("\n🔞 Explicit Content Visitor:")
    explicit_visitor = ExplicitContentVisitor()
    main_playlist.accept(explicit_visitor)
    if explicit_visitor.has_explicit_content():
        print(f"  ⚠️ Explicit songs found: {explicit_visitor.get_explicit_songs()}")
    else:
        print("  ✅ No explicit content found")
    
    print("\n" + "═" * 55)
    print("✅ All patterns implemented successfully!")
    print("═" * 55)


if __name__ == "__main__":
    main()