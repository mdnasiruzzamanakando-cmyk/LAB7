# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:20:51 2026

@author: AFraN NaSiR
"""

from typing import List
from composite.media_component import MediaComponent
from .playback_strategy import PlaybackStrategy

class SequentialPlay(PlaybackStrategy):
    """Concrete strategy - plays media in sequential order"""
    
    def play(self, playlist: List[MediaComponent]) -> None:
        print("\n[Sequential Mode] Playing in order:")
        for i, media in enumerate(playlist, 1):
            print(f"{i}. ", end="")
            media.play()
    
    def get_strategy_name(self) -> str:
        return "Sequential"