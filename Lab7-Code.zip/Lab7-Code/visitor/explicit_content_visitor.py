# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:25:45 2026

@author: AFraN NaSiR
"""

from typing import List
from .media_visitor import MediaVisitor

class ExplicitContentVisitor(MediaVisitor):
    """Concrete visitor that checks for explicit content in media"""
    
    def __init__(self):
        self._explicit_songs: List[str] = []
    
    def visit_song(self, song):
        if song.is_explicit:
            self._explicit_songs.append(song.title)
    
    def visit_playlist(self, playlist):
        # Just traverse
        pass
    
    def visit_video(self, video):
        # Videos could have explicit flag in real scenario
        pass
    
    def visit_podcast(self, podcast):
        # Podcasts could have explicit flag in real scenario
        pass
    
    def get_explicit_songs(self) -> List[str]:
        return self._explicit_songs
    
    def has_explicit_content(self) -> bool:
        return len(self._explicit_songs) > 0