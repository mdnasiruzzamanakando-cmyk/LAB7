# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:17:15 2026

@author: AFraN NaSiR
"""

from typing import List
from .media_component import MediaComponent

class Playlist(MediaComponent):
    """Composite node - can contain both Songs and other Playlists"""
    
    def __init__(self, name: str):
        self._name = name
        self._components: List[MediaComponent] = []
    
    def add_media(self, component: MediaComponent) -> None:
        """Add a media component (Song or Playlist) to this playlist"""
        self._components.append(component)
    
    def remove_media(self, component: MediaComponent) -> None:
        """Remove a media component from this playlist"""
        self._components.remove(component)
    
    def get_components(self) -> List[MediaComponent]:
        """Return all components in this playlist"""
        return self._components.copy()
    
    def get_name(self) -> str:
        return self._name
    
    def get_duration(self) -> int:
        """Calculate total duration by summing all child components"""
        total = 0
        for component in self._components:
            total += component.get_duration()
        return total
    
    def play(self) -> None:
        """Play all components in this playlist"""
        print(f"\n📁 === Playing Playlist: {self._name} ===")
        for component in self._components:
            component.play()
    
    def accept(self, visitor):
        """Accept a visitor and propagate to all children"""
        visitor.visit_playlist(self)
        for component in self._components:
            component.accept(visitor)