# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:25:07 2026

@author: AFraN NaSiR
"""

from typing import Dict
from .media_visitor import MediaVisitor

class GenreCountVisitor(MediaVisitor):
    """Concrete visitor that counts media by genre/type"""
    
    def __init__(self):
        self._genre_counts: Dict[str, int] = {}
    
    def visit_song(self, song):
        genre = song.genre
        self._genre_counts[genre] = self._genre_counts.get(genre, 0) + 1
    
    def visit_playlist(self, playlist):
        # Just traverse, don't count playlist itself
        pass
    
    def visit_video(self, video):
        self._genre_counts["Video"] = self._genre_counts.get("Video", 0) + 1
    
    def visit_podcast(self, podcast):
        self._genre_counts["Podcast"] = self._genre_counts.get("Podcast", 0) + 1
    
    def get_genre_counts(self) -> Dict[str, int]:
        return self._genre_counts