# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:21:42 2026

@author: AFraN NaSiR
"""

from typing import List
import random
from composite.media_component import MediaComponent
from .playback_strategy import PlaybackStrategy

class ShufflePlay(PlaybackStrategy):
    """Concrete strategy - plays media in random order"""
    
    def __init__(self):
        self._random = random.Random()
    
    def play(self, playlist: List[MediaComponent]) -> None:
        print("\n[Shuffle Mode] Playing in random order:")
        shuffled = playlist.copy()
        self._random.shuffle(shuffled)
        
        for i, media in enumerate(shuffled, 1):
            print(f"{i}. ", end="")
            media.play()
    
    def get_strategy_name(self) -> str:
        return "Shuffle"