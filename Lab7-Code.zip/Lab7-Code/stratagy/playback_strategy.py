# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:18:53 2026

@author: AFraN NaSiR
"""

from abc import ABC, abstractmethod
from typing import List
from composite.media_component import MediaComponent

class PlaybackStrategy(ABC):
    """Strategy interface for different playback algorithms"""
    
    @abstractmethod
    def play(self, playlist: List[MediaComponent]) -> None:
        pass
    
    @abstractmethod
    def get_strategy_name(self) -> str:
        pass