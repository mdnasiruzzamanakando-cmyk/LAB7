# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:15:54 2026

@author: AFraN NaSiR
"""

from abc import ABC, abstractmethod

class MediaComponent(ABC):
    """Abstract base class for all media components (Songs and Playlists)"""
    
    @abstractmethod
    def get_name(self) -> str:
        pass
    
    @abstractmethod
    def get_duration(self) -> int:
        """Returns duration in seconds"""
        pass
    
    @abstractmethod
    def play(self) -> None:
        pass
    
    @abstractmethod
    def accept(self, visitor):
        """Accept a visitor for the Visitor pattern"""
        pass