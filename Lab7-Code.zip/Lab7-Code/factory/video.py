# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 09:23:30 2026

@author: AFraN NaSiR
"""

from composite.media_component import MediaComponent

class Video(MediaComponent):
    """Video media type created by Factory pattern"""
    
    def __init__(self, title: str, director: str, duration: int, resolution: str):
        self._title = title
        self._director = director
        self._duration = duration
        self._resolution = resolution
    
    def get_name(self) -> str:
        return f"{self._title} (directed by {self._director})"
    
    def get_duration(self) -> int:
        return self._duration
    
    def play(self) -> None:
        print(f"🎬 Playing video: {self._title} [{self._duration}s, {self._resolution}]")
    
    def accept(self, visitor):
        visitor.visit_video(self)
    
    @property
    def title(self) -> str:
        return self._title
    
    @property
    def director(self) -> str:
        return self._director
    
    @property
    def resolution(self) -> str:
        return self._resolution